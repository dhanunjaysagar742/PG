import React, { useState, useEffect } from 'react';
import { AlertTriangle, Eye, RefreshCw, FileText } from 'lucide-react';

const UnauthorizedDevices = () => {
  const [devices, setDevices] = useState([]);
  const [filteredDevices, setFilteredDevices] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState('all');
  const [selectedDevice, setSelectedDevice] = useState(null);
  const [notes, setNotes] = useState('');

  const API_BASE = 'http://localhost:8080/api/unauthorized-devices';

  useEffect(() => {
    fetchDevices();
  }, []);

  useEffect(() => {
    filterDevices();
  }, [devices, filter]);

  const fetchDevices = async () => {
    try {
      const response = await fetch(API_BASE);
      const data = await response.json();
      setDevices(data);
    } catch (error) {
      console.error('Error fetching unauthorized devices:', error);
    }
  };

  const filterDevices = () => {
    let filtered = devices;
    if (filter === 'high-risk') {
      filtered = devices.filter(device => device.riskLevel === 'HIGH' || device.riskLevel === 'CRITICAL');
    } else if (filter === 'uninvestigated') {
      filtered = devices.filter(device => !device.isInvestigated);
    }
    setFilteredDevices(filtered);
  };

  const performScan = async () => {
    setLoading(true);
    try {
      await fetch(`${API_BASE}/scan`, { method: 'POST' });
      fetchDevices();
    } catch (error) {
      console.error('Error performing scan:', error);
    } finally {
      setLoading(false);
    }
  };

  const markAsInvestigated = async (id) => {
    try {
      await fetch(`${API_BASE}/${id}/investigate`, { method: 'PUT' });
      fetchDevices();
    } catch (error) {
      console.error('Error marking as investigated:', error);
    }
  };

  const updateRiskLevel = async (id, riskLevel) => {
    try {
      await fetch(`${API_BASE}/${id}/risk-level`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ riskLevel })
      });
      fetchDevices();
    } catch (error) {
      console.error('Error updating risk level:', error);
    }
  };

  const saveNotes = async (id) => {
    try {
      await fetch(`${API_BASE}/${id}/notes`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ notes })
      });
      fetchDevices();
      setSelectedDevice(null);
      setNotes('');
    } catch (error) {
      console.error('Error saving notes:', error);
    }
  };

  const getRiskColor = (riskLevel) => {
    switch (riskLevel) {
      case 'HIGH': return 'bg-red-100 text-red-800';
      case 'CRITICAL': return 'bg-red-200 text-red-900';
      case 'MEDIUM': return 'bg-yellow-100 text-yellow-800';
      case 'LOW': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Unauthorized Devices</h1>
          <p className="text-gray-600">Monitor and investigate unauthorized devices detected on your network</p>
        </div>
        <button
          onClick={performScan}
          disabled={loading}
          className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          {loading ? 'Scanning...' : 'Scan for Threats'}
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex space-x-4">
          <select
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option value="all">All Devices</option>
            <option value="high-risk">High Risk Only</option>
            <option value="uninvestigated">Uninvestigated Only</option>
          </select>
        </div>
      </div>

      {/* Device Table */}
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  IP Address
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  MAC Address
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Hostname
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Vendor
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Risk Level
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Detection Count
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  First Detected
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredDevices.map((device) => (
                <tr key={device.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                    {device.ipAddress}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 font-mono">
                    {device.macAddress}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {device.hostname || 'Unknown'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {device.vendor || 'Unknown'}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <select
                      value={device.riskLevel}
                      onChange={(e) => updateRiskLevel(device.id, e.target.value)}
                      className={`text-xs px-2 py-1 rounded-full border-0 ${getRiskColor(device.riskLevel)}`}
                    >
                      <option value="LOW">LOW</option>
                      <option value="MEDIUM">MEDIUM</option>
                      <option value="HIGH">HIGH</option>
                      <option value="CRITICAL">CRITICAL</option>
                    </select>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                      {device.detectionCount}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {new Date(device.firstDetected).toLocaleString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      device.isInvestigated ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {device.isInvestigated ? 'Investigated' : 'Pending'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex space-x-2">
                      <button
                        onClick={() => {
                          setSelectedDevice(device);
                          setNotes(device.notes || '');
                        }}
                        className="text-blue-600 hover:text-blue-900"
                        title="Add Notes"
                      >
                        <FileText className="w-4 h-4" />
                      </button>
                      {!device.isInvestigated && (
                        <button
                          onClick={() => markAsInvestigated(device.id)}
                          className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs hover:bg-green-200"
                        >
                          Mark as Investigated
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredDevices.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No unauthorized devices found.
        </div>
      )}

      {/* Notes Modal */}
      {selectedDevice && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <h3 className="text-lg font-semibold mb-4">
              Add Notes for {selectedDevice.ipAddress}
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Investigation Notes
                </label>
                <textarea
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  rows="4"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Enter investigation notes, findings, or actions taken..."
                />
              </div>
              <div className="flex justify-end space-x-3">
                <button
                  onClick={() => {
                    setSelectedDevice(null);
                    setNotes('');
                  }}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  onClick={() => saveNotes(selectedDevice.id)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  Save Notes
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UnauthorizedDevices;