// ===========================================
// FRONTEND CODE - React Application
// ===========================================

// File: src/App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Shield, ShieldAlert, Monitor, BarChart3 } from 'lucide-react';
import Dashboard from './components/Dashboard';
import AuthorizedDevices from './components/AuthorizedDevices';
import UnauthorizedDevices from './components/UnauthorizedDevices';
import './App.css';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        {/* Navigation */}
        <nav className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex">
                <div className="flex-shrink-0 flex items-center">
                  <Monitor className="h-8 w-8 text-blue-600" />
                  <span className="ml-2 text-xl font-semibold text-gray-900">
                    Network Discovery
                  </span>
                </div>
                <div className="ml-10 flex space-x-8">
                  <Link
                    to="/"
                    className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                      activeTab === 'dashboard'
                        ? 'border-blue-500 text-gray-900'
                        : 'border-transparent text-gray-500 hover:text-gray-700'
                    }`}
                    onClick={() => setActiveTab('dashboard')}
                  >
                    <BarChart3 className="w-4 h-4 mr-2" />
                    Dashboard
                  </Link>
                  <Link
                    to="/authorized"
                    className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                      activeTab === 'authorized'
                        ? 'border-blue-500 text-gray-900'
                        : 'border-transparent text-gray-500 hover:text-gray-700'
                    }`}
                    onClick={() => setActiveTab('authorized')}
                  >
                    <Shield className="w-4 h-4 mr-2" />
                    Authorized Devices
                  </Link>
                  <Link
                    to="/unauthorized"
                    className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                      activeTab === 'unauthorized'
                        ? 'border-blue-500 text-gray-900'
                        : 'border-transparent text-gray-500 hover:text-gray-700'
                    }`}
                    onClick={() => setActiveTab('unauthorized')}
                  >
                    <ShieldAlert className="w-4 h-4 mr-2" />
                    Unauthorized Devices
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/authorized" element={<AuthorizedDevices />} />
            <Route path="/unauthorized" element={<UnauthorizedDevices />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;





// File: src/components/UnauthorizedDevices.js



// File: src/index.js
// import React from 'react';
// import ReactDOM from 'react-dom/client';
// import './index.css';
// import App from './App';

// const root = ReactDOM.createRoot(document.getElementById('root'));
// root.render(
//   <React.StrictMode>
//     <App />
//   </React.StrictMode>
// );

// // File: src/index.css
// @tailwind base;
// @tailwind components;
// @tailwind utilities;

// /* Custom styles */
// .table-hover tbody tr:hover {
//   background-color: #f9fafb;
// }

// /* File: src/App.css
// .App {
//   text-align: center;
// }

// /* File: tailwind.config.js
// /** @type {import('tailwindcss').Config} */
// module.exports = {
//   content: [
//     "./src/**/*.{js,jsx,ts,tsx}",
//   ],
//   theme: {
//     extend: {},
//   },
//   plugins: [],
// }

